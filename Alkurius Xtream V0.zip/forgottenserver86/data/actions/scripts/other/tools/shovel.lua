function onUse(player, item, itemEx, fromPosition, target, toPosition, isHotkey)
	return onUseShovel(player, item, itemEx, fromPosition, target, toPosition, isHotkey)
end
