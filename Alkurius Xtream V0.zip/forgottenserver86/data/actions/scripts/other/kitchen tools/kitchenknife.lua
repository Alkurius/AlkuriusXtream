function onUse(player, item, fromPosition, target, toPosition, isHotkey)	
	return onUseKitchenKnife(player, item, fromPosition, target, toPosition, isHotkey)
end
